# TA-06: Simulasi Sistem Dinamik Suhu Ruangan ber-AC

**Nama:** Ari Mauludin | **NIM:** 301240044 | **Kelas:** 5C  
**Mata Praktikum:** Pemodelan dan Simulasi, Modul 6 (Dynamic System Modelling)

Model ODE orde satu (parameter terpusat) untuk suhu ruangan yang didinginkan AC:

    C * dT/dt = (T_out - T)/R + Q_int - Q_max * u

Parameter: C = 200.000 J/K, R = 0,01 K/W, Q_max = 1000 W, T_out = 32 C, Q_int = 300 W
(konstanta waktu tau = R*C = 2000 s). Integrasi numerik dengan metode Euler (dt = 10 s).

## Isi
- `simulasi_suhu_ruangan.py` : program utama (steady state + respon step, ramp, impuls, sinusoida)
- `TA6_Ari_Mauludin.ipynb`   : notebook yang sama beserta output
- `grafik_*.png`             : hasil grafik simulasi
- `diagram_sistem.png`, `diagram_stockflow.png` : diagram sistem

## Cara menjalankan
    pip install numpy matplotlib
    python simulasi_suhu_ruangan.py
